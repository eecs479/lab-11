import numpy as np
import math
import unittest

import qiskit
from qiskit.circuit import *
from typing import Dict, List
from qiskit_aer import AerSimulator
from qiskit import transpile

import lab_11

class TestLab11(unittest.TestCase):
    THRESHOLD = .15

    
        
    
    def run_test(self, state: np.array, correct: List[float], insert_bug: bool=False):
        np.random.seed(0)
        
        estimates = []
        tests = [lab_11.FT_meas_X, lab_11.FT_meas_Y, lab_11.FT_meas_Z]
        for test in tests:
            
            # Construct circuit
            data = QuantumRegister(3, name="data")
            cat = AncillaRegister(3, name="cat")
            anc = AncillaRegister(3, name="anc")
            cat_check = ClassicalRegister(3, name="cat_check")  
            result = ClassicalRegister(3, name="result")          
            qc = QuantumCircuit(data,cat,anc,cat_check,result)
            
            # Initialize data and encode into bit-flip code
            qc.initialize(state, data[0])
            qc.cx(data[0],data[1])
            qc.cx(data[0],data[2])
            
            
            # Run student student code
            test(qc, data, cat, anc, cat_check, result)
            
            if insert_bug:
                # Insert Y error and random point on ancilla qubits
                random_gate_index = np.random.randint(len(qc))  # Pick a random gate
                random_qubit_index = np.random.randint(6) # Pick a random ancilla qubit
                qc.data.insert(random_gate_index + 1, CircuitInstruction(qiskit.circuit.library.YGate(), [3+random_qubit_index], []))
                
            
        
            # Run simulation
            sim = AerSimulator()
            transpiled = transpile(qc,sim)
            
            # calculate Pr(0)-Pr(1)
            counts = sim.run(transpiled).result().get_counts()
            estimate = lab_11.process_counts(counts)
            estimates.append(estimate)
        

        # check each test
        for estimate,correct in zip(estimates, correct):
            self.assertTrue(abs(estimate-correct) < self.THRESHOLD)
        


    def test_Z(self):
        # test along z-axis
        self.run_test([1,0], [0,0,1])
        self.run_test([0,1], [0,0,-1])

    def test_X(self):
        # test along x-axis
        self.run_test(1/np.sqrt(2)*np.array([1,1]), [1,0,0])
        self.run_test(1/np.sqrt(2)*np.array([1,-1]), [-1,0,0])

    def test_Y(self):
        # test along y-axis
        self.run_test(1/np.sqrt(2)*np.array([1,1j]), [0,1,0])
        self.run_test(1/np.sqrt(2)*np.array([1,-1j]), [0,-1,0])

    def test_general(self):
        # test general state
        state = [math.sqrt(.68), math.sqrt(.32)*np.exp(1.16j*math.pi)]
        self.run_test(state, [-.82,-.45,.36])
        
        
    def test_prepare_ancilla(self):
        # Construct circuit
        cat = AncillaRegister(3, name="cat")
        anc = AncillaRegister(3, name="anc")
        cl = ClassicalRegister(3, name="cl")
        qc = QuantumCircuit(cat,anc,cl)
        lab_11.prepare_ancilla(qc,cat,anc,cl)
        
        qc.measure(cat,cl)
        
        sim = AerSimulator()
        transpiled = transpile(qc,sim)
        counts = sim.run(transpiled).result().get_counts()
        pr000 = counts.get("000",0) / 1024
        pr111 = counts.get("111",0) / 1024
        self.assertTrue(abs(pr000-0.5) < self.THRESHOLD)
        self.assertTrue(abs(pr111-0.5) < self.THRESHOLD)
        self.assertTrue(all(key in ("000", "111") for key in counts))
        
        
        

    num_iterations = 10

    def test_Z_error(self):
        # test along z-axis
        for _ in range(self.num_iterations):
            self.run_test([1,0], [0,0,1], insert_bug=True)
            self.run_test([0,1], [0,0,-1], insert_bug=True)

    def test_X_error(self):
        # test along x-axis
        for _ in range(self.num_iterations):
            self.run_test(1/np.sqrt(2)*np.array([1,1]), [1,0,0], insert_bug=True)
            self.run_test(1/np.sqrt(2)*np.array([1,-1]), [-1,0,0], insert_bug=True)

    def test_Y_error(self):
        # test along y-axis
        for _ in range(self.num_iterations):
            self.run_test(1/np.sqrt(2)*np.array([1,1j]), [0,1,0], insert_bug=True)
            self.run_test(1/np.sqrt(2)*np.array([1,-1j]), [0,-1,0], insert_bug=True)

    def test_general_error(self):
        # test general state
        for _ in range(self.num_iterations):
            state = [math.sqrt(.68), math.sqrt(.32)*np.exp(1.16j*math.pi)]
            self.run_test(state, [-.82,-.45,.36], insert_bug=True)

    def test_process_counts(self):
        test_counts = {
            '000 010': 10,
            '001 110': 5,
            '011 100': 8,
            '111 011': 12,
            '100 110': 7,
            '101 010': 3,
            '010 001': 4,
            '110 011': 6,
        }
        expected = (26 - 29) / (26 + 29)
        self.assertTrue(lab_11.process_counts(test_counts) == expected)

if __name__ == "__main__":
	unittest.main()