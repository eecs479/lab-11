from qiskit import *
import numpy as np
from qiskit.circuit import *
from qiskit.quantum_info import Statevector
from qiskit.circuit.classical import expr
from collections import defaultdict

def decode_and_measure( qc: QuantumCircuit, cat: AncillaRegister,
                        result_bit: Clbit):
    """Takes quantum circuit with 1 logical qubit (encoded over 3 physical
    qubits) with at least 3 ancilla qubits and at least 1 classical bit
    
    Decodes the logical qubit and writes the result onto the provided classical bit"""
    for i in range(1,3):
        qc.cx(cat[0],cat[i])
    qc.h(cat[0])
    qc.barrier()
    qc.measure(cat[0],result_bit)
    qc.barrier()

    
def prepare_ancilla(    qc: QuantumCircuit, cat: AncillaRegister,
                        anc: AncillaRegister, cat_check: ClassicalRegister):
    """Takes quantum circuit with 1 logical qubit (encoded over 3 physical
    qubits) in unknown state, plus 6 ancilla qubits and 6 classical bits
    
    Fault-tolerantly prepares the cat ancilla bits to the state |000>+|111>
    by iteratively applying gates and checking the parity of each pair of qubits"""

    # YOUR CODE HERE - prepare the cat state with H and CX gates
    invalid = expr.not_equal(cat_check, 0b000)
    with qc.while_loop(invalid):
        # YOUR CODE HERE - repeat preperation
    




    
def FT_meas_X(  qc: QuantumCircuit, data: QuantumRegister,
                cat: AncillaRegister, anc: AncillaRegister,
                cat_check: ClassicalRegister, result: ClassicalRegister):
    """Takes quantum circuit with 1 logical qubit (encoded over 3 physical
    qubits) in unknown state, plus 6 ancilla qubits and 6 classical bits
    
    Adds gates to fault-tolerantly measure along X axis"""

    for i in range(3):
        prepare_ancilla(qc,cat,anc,cat_check)
        # YOUR CODE - HERE - apply controlled gates and call decode_and_measure
    
    
def FT_meas_Y(  qc: QuantumCircuit, data: QuantumRegister,
                cat: AncillaRegister, anc: AncillaRegister,
                cat_check: ClassicalRegister, result: ClassicalRegister):
    """Takes quantum circuit with 1 logical qubit (encoded over 3 physical
    qubits) in unknown state, plus 6 ancilla qubits and 6 classical bits
    
    Adds gates to fault-tolerantly measure along Y axis"""

    for i in range(3):
        prepare_ancilla(qc,cat,anc,cat_check)
        # YOUR CODE - HERE - apply controlled gates and call decode_and_measure
        # CAREFUL WITH Y GATE!! Applying 3 Y gates will cause phase to be off by -1
    
    
def FT_meas_Z(  qc: QuantumCircuit, data: QuantumRegister,
                cat: AncillaRegister, anc: AncillaRegister,
                cat_check: ClassicalRegister, result: ClassicalRegister):
    """Takes quantum circuit with 1 logical qubit (encoded over 3 physical
    qubits) in unknown state, plus 6 ancilla qubits and 6 classical bits
    
    Adds gates to fault-tolerantly measure along Z axis"""

    for i in range(3):
        prepare_ancilla(qc,cat,anc,cat_check)
        # YOUR CODE - HERE - apply controlled gates and call decode_and_measure
    
    
def process_counts(counts: dict[str, int]) -> float:
    """Takes in count dictionary returned by Aer simulator
    where the three most significant bits are the results
    of each measurement
    
    Calculates a majority vote for each of these experiments
    and returns percentage of experiments where a majority
    of the results were 0, minus the percentage where a
    majority were 1"""
    
    
    zeros_sum = 0
    ones_sum = 0

    # YOUR CODE HERE
    
    return (zeros_sum - ones_sum) / (zeros_sum + ones_sum)